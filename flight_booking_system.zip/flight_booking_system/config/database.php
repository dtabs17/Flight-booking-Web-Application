<?php
/**
* This file contains the database configuration for this application
* 
*/

/**
* The database must be configured for the users environment 
* 
*/

//Make sure connection parameters are correct
$DBServer = '127.0.0.1'; // e.g 'localhost' or '127.0.0.1'
$DBportNr = '3306'; //MySQL Server port nr.
$DBUser   = 'root';  //the MySQL user name
$DBPass   = '';  //the MySQL user password
$DBName   = 'K00278226_flight_booking_system'; //the MySQL database name


