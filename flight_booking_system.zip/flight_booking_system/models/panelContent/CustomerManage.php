<?php

/**
 * This file contains the CustomerManage Class
 * 
 */


/**
 * UnderConstruction is an extended PanelModel Class
 * 
 * The purpose of this class is to generate HTML view panel headings and template content
 * for an <em><b> CustomerManage</b></em>  page.  The content generated is intended for 3 panel
 * view layouts. 
 * 
 * This class is intended as a TEMPLATE - to be copied and modified to provide
 * specific panel content.  
 *
 * @author gerry.guinane
 * 
 */

class CustomerManage extends PanelModel
{

    /**
     * Constructor Method
     * 
     * The constructor for the PanelModel class. The ManageSystems class provides the 
     * panel content for up to 3 page panels.
     * 
     * @param User $user  The current user
     * @param MySQLi $db The database connection handle
     * @param Array $postArray Copy of the $_POST array
     * @param String $pageTitle The page Title
     * @param String $pageHead The Page Heading
     * @param String $pageID The currently selected Page ID
     * 
     */
    function __construct($user, $db, $postArray, $pageTitle, $pageHead, $pageID)
    {
        $this->modelType = 'CustomerManage';
        parent::__construct($user, $db, $postArray, $pageTitle, $pageHead, $pageID);
    }


    /**
     * Set the Panel 1 heading 
     */
    public function setPanelHead_1()
    {
        //$this->panelHead_1='<h3>Panel 1</h3>';
        switch ($this->pageID) {
            case "viewAllFlights":
                $this->panelHead_1 = '<h3>View All Available Flights</h3>';
                break;
            case "viewBookings":
                $this->panelHead_1 = '<h3>View Bookings</h3>';
                break;
            case "bookFlights":
                $this->panelHead_1 = '<h3>Book Flights</h3>';
                break;
            default:  //DEFAULT menu item handler
                $this->panelHead_1 = '<h3>Manage Products</h3>';
                break;
        } //end switch   
    }

    /**
     * Set the Panel 1 text content
     */
    public function setPanelContent_1()
    {
        switch ($this->pageID) {
            case "viewAllFlights":
                $flightsTable = new FlightsTable($this->db);

                $rs = $flightsTable->getAllFlights();

                if ($rs) {
                    $this->panelContent_1 = HelperHTML::generateTABLE($rs);
                } else {
                    $this->panelContent_1 = 'No Available Flights found';
                }
                break;

            case "viewBookings":
                $this->panelContent_1 = Form::form_view_bookings($this->pageID);

                if (isset($_POST['submit1'])) {
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "K00278226_flight_booking_system";

                    $userId = $_POST['userID'];

                    $conn = new mysqli($servername, $username, $password, $dbname);

                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }


                    $stmt = $conn->prepare("SELECT * FROM bookings WHERE user_id = ?");
                    $stmt->bind_param("s", $userId);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows > 0) {
                        $this->panelContent_1 = HelperHTML::generateTABLE($result);
                    } else {
                        $this->panelContent_1 = 'No Available Bookings found';
                    }

                    $stmt->close();
                    $conn->close();
                }

                break;

            case "bookFlights":
                $this->panelContent_2 = "Please fill in the form to book a flight.";

                $this->panelContent_1 = Form::form_book_flight($this->pageID);

                if (isset($_POST['submit'])) {
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "K00278226_flight_booking_system";
                    $flightId = $_POST['flightId'];
                    $userId = $_POST['userID'];

                    $conn = new mysqli($servername, $username, $password, $dbname);

                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $stmt = $conn->prepare("SELECT flight_id FROM flights WHERE flight_id = ?");
                    $stmt->bind_param("i", $flightId);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows == 0) {
                        $this->panelContent_2 = "Unable to book. Flight does not exist.";
                        $stmt->close();
                    } else {
                        $stmt = $conn->prepare("SELECT userID FROM user WHERE userID = ?");
                        $stmt->bind_param("s", $userId);
                        $stmt->execute();
                        $userResult = $stmt->get_result();

                        if ($userResult->num_rows == 0) {
                            $this->panelContent_2 = "Unable to book. User ID does not exist.";
                            $stmt->close();
                        } else {

                            $stmt = $conn->prepare("INSERT INTO bookings (flight_id, user_id, booking_status) VALUES (?, ?, 'CONFIRMED')");
                            $stmt->bind_param("is", $flightId, $userId);

                            if ($stmt->execute()) {
                                $this->panelContent_2 = "Booking successful!";
                            } else {
                                $this->panelContent_2 = "Error: " . $stmt->error;
                            }
                            $stmt->close();
                        }
                    }
                }

                break;
            default:
                $this->panelContent_1 = '<h3>Manage Products</h3>';
                break;
        }
    }

    public function setPanelHead_2()
    {
        switch ($this->pageID) {
            case "viewAllFlights":
                $this->panelHead_2 = '<h3>View Flights</h3>';
                break;
            case "viewBookings":
                $this->panelHead_2 = '<h3>View Bookings</h3>';
                break;
            case "bookFlights":
                $this->panelHead_2 = '<h3>Book Flights</h3>';
                break;
            default:  //DEFAULT menu item handler
                $this->panelHead_2 = '<h3>Manage Products</h3>';
                break;
        }
    }

    /**
     * Set the Panel 2 text content 
     */
    public function setPanelContent_2()
    {
        $this->panelContent_2 = "Panel 2 content for <b>$this->pageHeading</b> menu item is under construction.";
    }

    /**
     * Set the Panel 3 heading 
     */
    public function setPanelHead_3()
    {
        switch ($this->pageID) {
            case "viewAllFlights":
                $this->panelHead_3 = '<h3>View Flights</h3>';
                break;
            case "viewBookings":
                $this->panelHead_3 = '<h3>View Bookings</h3>';
                break;
            case "bookFlights":
                $this->panelHead_3 = '<h3>Book Flights</h3>';
                break;
            default:  //DEFAULT menu item handler
                $this->panelHead_2 = '<h3>Manage Products</h3>';
                break;
        }
    }

    /**
     * Set the Panel 3 text content 
     */
    public function setPanelContent_3()
    {
        $this->panelContent_3 = "Panel 3 content for <b>$this->pageHeading</b> menu item is under construction.";
    }
}
