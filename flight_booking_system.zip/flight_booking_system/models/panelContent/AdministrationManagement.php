<?php

/**
 * This file contains the ManagerManageProducts Class
 * 
 */


/**
 * ManagerManageProducts is an extended PanelModel Class
 * 
 * The purpose of this class is to generate HTML view panel headings and template content
 * for an <em><b>ManagerManageProducts</b></em>  page.  The content generated is intended for 3 panel
 * view layouts. 
 * 
 * This class is intended as a TEMPLATE - to be copied and modified to provide
 * specific panel content.  
 *
 * @author gerry.guinane
 * 
 */

class ManagerManageProducts extends PanelModel
{

    /**
     * Constructor Method
     * 
     * The constructor for the PanelModel class. The ManagerManageProducts class provides the 
     * panel content for up to 3 page panels.
     * 
     * @param User $user  The current user
     * @param MySQLi $db The database connection handle
     * @param Array $postArray Copy of the $_POST array
     * @param String $pageTitle The page Title
     * @param String $pageHead The Page Heading
     * @param String $pageID The currently selected Page ID
     * 
     */
    function __construct($user, $db, $postArray, $pageTitle, $pageHead, $pageID)
    {
        $this->modelType = 'ManagerManageProducts';
        parent::__construct($user, $db, $postArray, $pageTitle, $pageHead, $pageID);
    }


    /**
     * Set the Panel 1 heading 
     */
    public function setPanelHead_1()
    {

        switch ($this->pageID) {
            case "viewFlights":
                $this->panelHead_1 = '<h3>View Flights</h3>';
                break;

            case "addFlights":
                $this->panelHead_1 = '<h3>Add Flights</h3>';
                break;

            case "editFlights":
                $this->panelHead_1 = '<h3>Edit Flights</h3>';
                break;

            case "cancelBookings":
                $this->panelHead_1 = '<h3>Cancel Bookings</h3>';

                break;
            case "viewBookings":
                $this->panelHead_1 = '<h3>View Bookings</h3>';
                break;

            case "viewAirlines":
                $this->panelHead_1 = '<h3>View Airlines</h3>';
                break;
            case "addAirline":
                $this->panelHead_1 = '<h3>Add Airline</h3>';
                break;

            default:  //DEFAULT menu item handler
                $this->panelHead_1 = '<h3>Manage Flights</h3>';
                break;
        } //end switch   

    }

    /**
     * Set the Panel 1 text content 
     */
    public function setPanelContent_1()
    {

        switch ($this->pageID) 
        {
            case "viewFlights":
                $flightsTable = new FlightsTable($this->db);

                $rs = $flightsTable->getAllFlights();

                if ($rs) {
                    $this->panelContent_1 = HelperHTML::generateTABLE($rs);
                } else {
                    $this->panelContent_1 = 'No Available Flights found';
                }
                break;

            case "addFlights":  // Menu item handler
                $this->panelContent_2 = "Please enter the flight details";
                $FlightCategoriesTable = new FlightCategoriesTable($this->db);
                $this->panelContent_1 = Form::form_add_flight($FlightCategoriesTable, $this->pageID);
                if (isset($_POST['btnAddFlight'])) {
                    $servername = "localhost";
                    $dbname = "K00278226_flight_booking_system";
                    $username = "root";
                    $password = "";
                    $db = new mysqli($servername, $username, $password, $dbname);

                    if ($db->connect_error) {
                        die("Connection failed: " . $db->connect_error);
                    }

                    $airlineId = $_POST['airlineid'];
                    $checkAirlineIdStmt = $db->prepare("SELECT airline_id FROM airlines WHERE airline_id = ?");
                    $checkAirlineIdStmt->bind_param("i", $airlineId);
                    $checkAirlineIdStmt->execute();
                    $checkAirlineIdResult = $checkAirlineIdStmt->get_result();

                    if ($checkAirlineIdResult->num_rows == 0) {

                        $this->panelContent_2 = "Error: Could not add flight. The specified airline ID does not exist.";
                    }
                    else
                    {
                        $stmt = $db->prepare("INSERT INTO flights (flight_id, destination, departure_location, time_of_departure, time_of_arrival, airline_id, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmt->bind_param("issssis", $_POST['flightID'], $_POST['destination'], $_POST['departureLocation'], $_POST['timeOfDeparture'], $_POST['timeOfArrival'], $_POST['airlineid'], $_POST['status']);

                        // Execute
                        if ($stmt->execute()) {
                            $this->panelContent_2 = "New flight added successfully";
                        } else {
                            $this->panelContent_2 = "Error: " . $stmt->error;
                        }

                        $stmt->close();
                    }

                    $checkAirlineIdStmt->close();
                    $db->close();
                }

                break;

            case "addAirline":
                $this->panelContent_1 = Form::form_add_airline($this->pageID);
                $this->panelContent_2 = "Please fill in the form to add an airline.";
                if (isset($_POST['btnAddAirline'])) {

                    $servername = "localhost";
                    $dbname = "K00278226_flight_booking_system";
                    $username = "root";
                    $password = "";

                    $conn = new mysqli($servername, $username, $password, $dbname);

                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $stmt = $conn->prepare("INSERT INTO airlines (airline_id, airline_name) VALUES (?, ?)");
                    $stmt->bind_param("is", $airlineId, $airlineName);

                    $airlineId = $_POST['airlineId'];
                    $airlineName = $_POST['airlineName'];

                    if ($stmt->execute()) {
                        $this->panelContent_2 = "New airline added successfully";
                    } else {
                        $this->panelContent_2 = "Error: " . $stmt->error;
                    }

                    $stmt->close();
                    $conn->close();
                }
                break;

            case "viewAirlines":
                $flightsTable = new FlightsTable($this->db);

                $rs = $flightsTable->getAllAirlines();

                if ($rs) {
                    $this->panelContent_1 = HelperHTML::generateTABLE($rs);
                } else {
                    $this->panelContent_1 = 'No Available Airlines found';
                }
                break;

            case "editFlights":

                $flightsTable = new FlightsTable($this->db);
                $this->panelContent_2 = "Form will appear when a flight ID that exists has been typed in.";
                $this->panelContent_3 = "Please enter the flight details to be edited";

                $this->panelContent_1 = Form::form_initial_flight_id($this->pageID);

                if (isset($_POST['btnSearch'])) {
                    $rs = $flightsTable->getRecordByFlightID($_POST['flightId']);
                    if ($rs) {
                        $this->panelContent_2 = Form::form_edit_flight($this->pageID);
                        $this->panelContent_3 = "Flight Exists.";
                    } else {
                        $this->panelContent_3 = "Flight does not exist.";
                    }
                }


                if (isset($_POST['btnUpdateFlight'])) {
                    $servername = "localhost";
                    $dbname = "K00278226_flight_booking_system";
                    $username = "root";
                    $password = "";
                    $db = new mysqli($servername, $username, $password, $dbname);

                    if ($db->connect_error) {
                        die("Connection failed: " . $db->connect_error);
                    }

                    $airlineId = $_POST['airlineid'];
                    $checkAirlineIdStmt = $db->prepare("SELECT airline_id FROM airlines WHERE airline_id = ?");
                    $checkAirlineIdStmt->bind_param("i", $airlineId);
                    $checkAirlineIdStmt->execute();
                    $checkAirlineIdResult = $checkAirlineIdStmt->get_result();

                    if ($checkAirlineIdResult->num_rows == 0) {
                        $this->panelContent_3 = "Error: Airline ID does not exist. Cannot edit flight.";
                    } else {

                        $stmt = $db->prepare("UPDATE flights SET destination = ?, departure_location = ?,
                        time_of_departure = ?, time_of_arrival = ?, airline_id = ?, status = ? WHERE flight_id = ?");
                        $stmt->bind_param(
                            "ssssisi",
                            $_POST['destination'],
                            $_POST['departureLocation'],
                            $_POST['timeOfDeparture'],
                            $_POST['timeOfArrival'],
                            $airlineId,
                            $_POST['status'],
                            $_POST['flightID']
                        );

                        if ($stmt->execute()) {
                            $this->panelContent_3 = "Flight updated successfully";
                        } else {
                            $this->panelContent_3 = "Error updating flight: " . $stmt->error;
                        }

                        $stmt->close();
                    }

                    $checkAirlineIdStmt->close();
                    $db->close();
                }

                if (isset($_POST['btnDeleteFlight'])) {
                    $servername = "localhost";
                    $dbname = "K00278226_flight_booking_system";
                    $username = "root";
                    $password = "";
                    $db = new mysqli($servername, $username, $password, $dbname);

                    if ($db->connect_error) {
                        die("Connection failed: " . $db->connect_error);
                    }

                    $flightId = $_POST['flightID'];
                    $checkFlightIdStmt = $db->prepare("SELECT flight_id FROM flights WHERE flight_id = ?");
                    $checkFlightIdStmt->bind_param("i", $flightId);
                    $checkFlightIdStmt->execute();
                    $checkFlightIdResult = $checkFlightIdStmt->get_result();

                    if ($checkFlightIdResult->num_rows == 0) {
                        $this->panelContent_3 = "Error: Flight ID does not exist. Cannot delete flight.";
                    } else {

                        $stmt = $db->prepare("DELETE FROM flights WHERE flight_id = ?");
                        $stmt->bind_param("i", $flightId);

                        if ($stmt->execute()) {
                            $this->panelContent_3 = "Flight deleted successfully";
                        } else {
                            $this->panelContent_3 = "Error deleting flight: " . $stmt->error;
                        }

                        $stmt->close();
                    }

                    $checkFlightIdStmt->close();
                    $db->close();
                }

                break;

            case "cancelBookings":
                $this->panelContent_1 = Form::form_delete_booking($this->pageID);
                $this->panelContent_2 = "Please fill in the form to cancel a booking";

                if (isset($_POST['deleteBooking']))
                {
                    $servername = "localhost";
                    $dbname = "K00278226_flight_booking_system";
                    $username = "root";
                    $password = "";

                    $conn = new mysqli($servername, $username, $password, $dbname);

                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $bookingID = $conn->real_escape_string($_POST['bookingID']);

                    $checkSql = "SELECT booking_id FROM bookings WHERE booking_id = '$bookingID'";
                    $result = $conn->query($checkSql);

                    if ($result->num_rows > 0) {

                        $deleteSql = "DELETE FROM bookings WHERE booking_id = '$bookingID'";
                        if ($conn->query($deleteSql) === TRUE) {
                            $this->panelContent_2 = "Booking Cancelled successfully";
                        } else {
                            $this->panelContent_2 = "Error cancelling booking: " . $conn->error;
                        }
                    } else {
                        $this->panelContent_2 = "No booking found with ID: $bookingID";

                        $conn->close();
                    }
                }

                break;
                
                case "viewBookings":
                    $flightsTable = new FlightsTable($this->db);

                $rs = $flightsTable->getAllBookings();

                if ($rs) {
                    $this->panelContent_1 = HelperHTML::generateTABLE($rs); 
                } else {
                    $this->panelContent_1 = 'No Bookings found';
                }
                    break;
                default:
                    $this->panelContent_1 = "Panel 1 content for \$pageID <b>DEFAULT</b> menu item is under construction.";
                break;
        } //end switch

    
    }
    /**
     * Set the Panel 2 heading 
     */
    public function setPanelHead_2()
    {
        switch ($this->pageID) {
            case "viewFlights":
                $this->panelHead_2 = '<h3>View Flights</h3>';
                break;

            case "addFlights":
                $this->panelHead_2 = '<h3>Add Flights</h3>';
                break;

            case "editFlights":
                $this->panelHead_2 = '<h3>Edit Flights</h3>';
                break;

            case "viewBookings":
                $this->panelHead_2 = '<h3>View Bookings</h3>';
                break;

            case "cancelBookings":
                $this->panelHead_2 = '<h3>Cancel Bookings</h3>';

                break;

            case "addAirline":
                $this->panelHead_2 = '<h3>Add Airline</h3>';
                break;

            default:  // DEFAULT menu item handler
                $this->panelHead_2 = '<h3>Manage Flights</h3>';
                break;
        } //end switch   
    }

    /**
     * Set the Panel 2 text content 
     */
    public function setPanelContent_2()
    {
        switch ($this->pageID) {
            case "manageProducts":  // menu item handler
                $this->panelContent_2 = "Panel 1 content for \$pageID <b>$this->pageID</b> menu item is under construction.";
                break;
            case "viewProducts":  // menu item handler
                $this->panelContent_2 = "Panel 1 content for \$pageID <b>$this->pageID</b> menu item is under construction.";
                break;
            case "editProduct":  // menu item handler
                $this->panelContent_2 = "Panel 1 content for \$pageID <b>$this->pageID</b> menu item is under construction.";
                break;

            case "addFlights":  // menu item handler
                if (isset($_POST["btnAddProduct"])) {
                    $tableEnt = new FlightsTable($this->db);
                    if ($tableEnt->addFlight($_POST)) {
                        $this->panelContent_2 = "Flights Added";
                    } else {
                        $this->panelContent_2 = "Flights could not be added";
                    }
                } else {
                    $this->panelContent_2 = "Enter";
                }
                break;
            default:  // DEFAULT menu item handler
                $this->panelContent_2 = "Panel 1 content for \$pageID <b>DEFAULT</b> menu item is under construction.";
                break;
        } //end switch   
    }

    /**
     * Set the Panel 3 heading 
     */
    public function setPanelHead_3()
    {
        switch ($this->pageID) {
            case "manageProducts":  // menu item handler
                $this->panelHead_3 = '<h3>Manage Products</h3>';
                break;
            case "viewProducts":  // menu item handler
                $this->panelHead_3 = '<h3>View Products</h3>';
                break;
            case "editProduct":  // menu item handler
                $this->panelHead_3 = '<h3>Edit Product</h3>';
                break;
            case "addProduct":  // menu item handler
                $this->panelHead_3 = '<h3>Add Product</h3>';
                break;
            case "editFlights":  // menu item handler
                $this->panelHead_3 = '<h3>Edit Flights</h3>';
                break;

            default:  // DEFAULT menu item handler
                $this->panelHead_3 = '<h3>Manage Products</h3>';
                break;
        } //end switch   
    }

    /**
     * Set the Panel 3 text content 
     */
    public function setPanelContent_3()
    {
        switch ($this->pageID) {
            case "manageProducts":  // menu item handler
                $this->panelContent_3 = "Panel 1 content for \$pageID <b>$this->pageID</b> menu item is under construction.";
                break;
            case "viewProducts":  // menu item handler
                $this->panelContent_3 = "Panel 1 content for \$pageID <b>$this->pageID</b> menu item is under construction.";
                break;
            case "editProduct":  // menu item handler
                $this->panelContent_3 = "Panel 1 content for \$pageID <b>$this->pageID</b> menu item is under construction.";
                break;
            case "addProduct":  // menu item handler
                $this->panelContent_3 = "Panel 1 content for \$pageID <b>$this->pageID</b> menu item is under construction.";
                break;
            case "editFlights":
                //$this->panelContent_3="hi.";
                break;
            default:  // DEFAULT menu item handler
                $this->panelContent_3 = "Panel 1 content for \$pageID <b>DEFAULT</b> menu item is under construction.";
                break;
        } //end switch   
    }
}
