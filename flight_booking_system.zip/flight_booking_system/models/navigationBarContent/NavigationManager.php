<?php

/**
 * This file contains the NavigationManager Class
 * 
 */

/**
 * 
 * NavigationManager class is a model class that implements the content generation for the
 * page navigation bar for a logged in ADMIN user.  
 * 
 * @author Gerry Guinane
 * 
 */

class NavigationManager implements NavigationInterface
{

    /**
     *
     * @var boolean $loggedin User logged in state 
     */
    protected $loggedin;

    /**
     *
     * @var String $modelType Identifues this navigation model type  
     */
    protected $modelType;

    /**
     *
     * @var String $pageID The currently selected page
     */
    protected $pageID;

    /**
     *
     * @var array $menuNav An array of menu items  
     */
    protected $menuNav;

    /**
     *
     * @var User $user  The current user object. 
     */
    protected $user;


    /**
     * Class constructor. 
     * 
     * @param User $user The current user object.
     * @param string $pageID The currently selected page
     */
    function __construct($user, $pageID)
    {
        $this->loggedin = $user->getLoggedInState();
        $this->modelType = 'NavigationManager';
        $this->user = $user;
        $this->pageID = $pageID;
        $this->setmenuNav();
    }


    /**
     * Method to prepare the navigation menu depending on the currently selected page ID. 
     * 
     * This method implements handlers for each page ID.  It prepares a HTML list item string
     * containing the menu items that will appear in the view. This string may be returned using the 
     * getMenuNav() method of this class.
     * 
     * If a user is not properly logged in it force redirects to the website home page. 
     * 
     */
    public function setmenuNav()
    { //set the menu items depending on the users selected page ID

        //empty string for menu items
        $this->menuNav = '';

        $dropdownMenuManageProducts = '<li class="dropdown">';
        $dropdownMenuManageProducts .= '<a class="dropdown-toggle" data-toggle="dropdown" href="#">Manage Flights<span class="caret"></span></a>';
        $dropdownMenuManageProducts .= '<ul class="dropdown-menu">';
        $dropdownMenuManageProducts .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=viewFlights">View Flights</a></li>';
        $dropdownMenuManageProducts .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=addFlights">Add Flights</a></li>';
        $dropdownMenuManageProducts .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=addAirline">Add Airline</a></li>';
        $dropdownMenuManageProducts .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=viewAirlines">View Airlines</a></li>';
        $dropdownMenuManageProducts .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=editFlights">Edit Flights</a></li>';
        $dropdownMenuManageProducts .= '</ul></li>';

        $dropdownMenuManageProducts1 = '<li class="dropdown">';
        $dropdownMenuManageProducts1 .= '<a class="dropdown-toggle" data-toggle="dropdown" href="#">Manage Bookings<span class="caret"></span></a>';
        $dropdownMenuManageProducts1 .= '<ul class="dropdown-menu">';
        $dropdownMenuManageProducts1 .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=viewBookings">View Bookings</a></li>';
        $dropdownMenuManageProducts1 .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=cancelBookings">Cancel Bookings</a></li>';
        //$dropdownMenuManageProducts1.='<li><a href="'.$_SERVER['PHP_SELF'].'?pageID=manageUsers">Manage Users</a></li>';
        $dropdownMenuManageProducts1 .= '</ul></li>';

        if ($this->loggedin) {
            //handlers for logged in user
            switch ($this->pageID) 
            {
                    //home menu navigation
                case "home":
                    $this->menuNav .= $dropdownMenuManageProducts;
                    $this->menuNav .= $dropdownMenuManageProducts1;
                    //the MANAGE PRODUCTS drop down menu
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=myAccount">My Account</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=logout">Log Out</a></li>';

                    break;

                    //example of under construction menu item
                case "menuitem1":
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=myAccount">My Account</a></li>';
                    //$this->menuNav.='<li><a href="'.$_SERVER['PHP_SELF'].'?pageID=menuitem1">Menu Item 1</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=logout">Log Out</a></li>';
                    break;

                case "viewFlights":
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=home">Home</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=addFlights">Add Flight</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=addAirline">Add Airline</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=editFlights">Edit Flight</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=viewAirlines">View Airlines</a></li>';
                    //$this->menuNav.='<li><a href="'.$_SERVER['PHP_SELF'].'?pageID=addProduct">Add Product</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=logout">Log Out</a></li>';
                    break;

                case "addAirline":
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=home">Home</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=addFlights">Add Flight</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=editFlights">Edit Flight</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=viewFlights">View Flight</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=viewAirlines">View Airlines</a></li>';
                    //$this->menuNav.='<li><a href="'.$_SERVER['PHP_SELF'].'?pageID=addProduct">Add Product</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=logout">Log Out</a></li>';
                    break;

                case "viewAirlines":
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=home">Home</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=addFlights">Add Flight</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=editFlights">Edit Flight</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=viewFlights">View Flight</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=addAirline">Add Airline</a></li>';
                    //$this->menuNav.='<li><a href="'.$_SERVER['PHP_SELF'].'?pageID=addProduct">Add Product</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=logout">Log Out</a></li>';
                    break;


                case "editFlights":
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=home">Home</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=viewFlights">View Flight</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=addFlight">Add Flight</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=addAirline">Add Airline</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=viewAirlines">View Airlines</a></li>';
                    //$this->menuNav.='<li><a href="'.$_SERVER['PHP_SELF'].'?pageID=addProduct">Add Product</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=logout">Log Out</a></li>';
                    break;

                case "addFlights":
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=home">Home</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=viewFlights">View Flight</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=editFlights">Edit Flight</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=addAirline">Add Airline</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=viewAirlines">View Airlines</a></li>';
                    //$this->menuNav.='<li><a href="'.$_SERVER['PHP_SELF'].'?pageID=addProduct">Add Product</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=logout">Log Out</a></li>';
                    break;

                case "viewBookings":
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=home">Home</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=cancelBookings">Cancel Bookings</a></li>';
                    //$this->menuNav.='<li><a href="'.$_SERVER['PHP_SELF'].'?pageID=editFlights">Edit Flight</a></li>';
                    //$this->menuNav.='<li><a href="'.$_SERVER['PHP_SELF'].'?pageID=addProduct">Add Product</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=logout">Log Out</a></li>';
                    break;

                case "cancelBookings":
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=home">Home</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=viewBookings">View Bookings</a></li>';
                    //$this->menuNav.='<li><a href="'.$_SERVER['PHP_SELF'].'?pageID=editFlights">Edit Flight</a></li>';
                    //$this->menuNav.='<li><a href="'.$_SERVER['PHP_SELF'].'?pageID=addProduct">Add Product</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=logout">Log Out</a></li>';
                    break;

                    //my account navigation
                case "myAccount":
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=home">Home</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=editAccount">Edit Details</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=changePassword">Password Change</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=logout">Log Out</a></li>';
                    break;
                case "editAccount":
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=home">Home</a></li>';
                    //$this->menuNav.='<li><a href="'.$_SERVER['PHP_SELF'].'?pageID=editAccount">Edit Details</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=changePassword">Password Change</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=logout">Log Out</a></li>';
                    break;
                case "changePassword":
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=home">Home</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=editAccount">Edit Details</a></li>';
                    //$this->menuNav.='<li><a href="'.$_SERVER['PHP_SELF'].'?pageID=changePassword">Password Change</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=logout">Log Out</a></li>';
                    break;



                default:
                    //$this->menuNav.='<li><a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=myAccount">My Account</a></li>';
                    //$this->menuNav.='<li><a href="'.$_SERVER['PHP_SELF'].'?pageID=manageProducts">Manage Products</a></li>';
                    $this->menuNav .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?pageID=logout">Log Out</a></li>';
                    break;
            } //end switch                
        } else {
            //redirect to main index.php page
            header("Location:" . $_SERVER['PHP_SELF']);
        }
    }

    /**
     * Getter to return the HTML menu string. 
     * 
     * @return string Containing  a HTML list item string containing the menu items that will appear in the view.
     */
    public function getMenuNav()
    {
        return $this->menuNav;
    }

    /**
     * Dumps diagnostic information in HTML format relating to the class properties
     */
    public function getDiagnosticInfo()
    {

        echo '<!-- NAVIGATION MANAGER CLASS PROPERTY SECTION  -->';
        echo '<div class="container-fluid"   style="background-color: #AAAAAA">'; //outer DIV

        echo '<h3>NAVIGATION MANAGER (CLASS) properties</h3>';
        echo '<table border=1 border-style: dashed; style="background-color: #EEEEEE" >';
        echo '<tr><th>PROPERTY</th><th>VALUE</th></tr>';
        echo "<tr><td>pageID</td>   <td>$this->pageID</td></tr>";
        echo "<tr><td>menuNav</td>  <td>$this->menuNav      </td></tr>";
        echo '</table>';
        echo '<p><hr>';
        echo '</div>';
        echo '<!-- END NAVIGATION CLASS PROPERTY SECTION  -->';
    }
}
