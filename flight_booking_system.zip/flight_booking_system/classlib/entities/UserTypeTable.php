<?php
/**
* This file contains the UserTypeTable Class
* 
*/

/**
 * 
 * UserTypeTable entity class implements the table entity class for the 'usertype' table in the database. 
 * 
 * @author Gerry Guinane
 * 
 */

class UsersTable extends TableEntity {
    /**
     * Constructor for the UsersTable Class
     * 
     * @param MySQLi $databaseConnection The database connection object. 
     */
    function __construct($databaseConnection){
        parent::__construct($databaseConnection, 'users'); // The name of the table is passed to the parent constructor
    }
    // END METHOD: Construct
    
    /**
     * Returns a user record by ID from the users table.
     * 
     * @param string $userID The user's ID.
     * @return mixed Returns false on failure. For successful SELECT, returns a mysqli_result object $rs.
     */ 
    public function getRecordByID($userID){
        $this->SQL = "SELECT * FROM users WHERE user_id = ?";
        try {
            $stmt = $this->db->prepare($this->SQL);
            $stmt->bind_param("s", $userID);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 1) {
                return $result->fetch_assoc(); // Returning the user record as an associative array
            } else {
                return false; // No user found or multiple records returned, which should not happen
            }
        } catch (mysqli_sql_exception $e) {
            $this->MySQLiErrorNr = $e->getCode();
            $this->MySQLiErrorMsg = $e->getMessage();
            return false;
        }
    }

    /**
     * Returns all user records from the users table, optionally filtered by userType.
     * 
     * @param string $userType Optional. If specified, filters users by this type.
     * @return mixed Returns false on failure. For successful SELECT, returns a mysqli_result object $rs.
     */
    public function getAllRecords($userType = null){
        if ($userType === null) {
            $this->SQL = "SELECT * FROM users";
        } else {
            $this->SQL = "SELECT * FROM users WHERE userType = ?";
        }
        
        try {
            if ($userType === null) {
                $rs = $this->db->query($this->SQL);
            } else {
                $stmt = $this->db->prepare($this->SQL);
                $stmt->bind_param("s", $userType);
                $stmt->execute();
                $rs = $stmt->get_result();
            }
            
            if ($rs->num_rows > 0) {
                return $rs; // Return the resultset for further processing
            } else {
                return false; // No records found
            }
        } catch (mysqli_sql_exception $e) {
            $this->MySQLiErrorNr = $e->getCode();
            $this->MySQLiErrorMsg = $e->getMessage();
            return false;
        }
    }
}

