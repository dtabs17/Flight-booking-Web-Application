<?php
/**
 * This file contains the FlightsTable Class for managing flight information in the database.
 */

class FlightsTable extends TableEntity {

    /**
     * Constructor for the FlightsTable Class
     * 
     * @param MySQLi $databaseConnection  The database connection object. 
     */
    function __construct($databaseConnection){
        parent::__construct($databaseConnection, 'flights');  // The name of the table is passed to the parent constructor
    }

    /**
     * Updates a flight record in the database table - flights.
     *
     * @param array $postArray Copy of $_POST array containing data to be updated
     * @return boolean
     */
    public function updateFlight($postArray) {
        // Assuming $postArray has been validated and sanitized appropriately
        // Ensure you have keys in $postArray named: flight_id, destination, departureLocation,
        // timeOfDeparture, timeOfArrival, airline_id, and status that correspond to your form fields and database columns.
    
        // Prepared statement with named placeholders for better readability
        $sql = "UPDATE flights SET
                    Destination = ?,
                    DepartureLocation = ?,
                    TimeOfDeparture = ?,
                    TimeOfArrival = ?,
                    Airline_id = ?,
                    Status = ?
                WHERE Flight_id = ?";
    
        $stmt = $this->db->prepare($sql);
    
        if ($stmt) {
            // Bind the parameters to the statement
            // Note: Adjust 'i' or 's' based on the actual data types of your columns
            $stmt->bind_param("sssssii",
                $postArray['destination'],
                $postArray['departureLocation'],
                $postArray['timeOfDeparture'],
                $postArray['timeOfArrival'],
                $postArray['airline_id'],
                $postArray['status'],
                $postArray['flight_id']);
    
            if ($stmt->execute()) {
                $stmt->close();
                return true; // Update successful
            } else {
                $this->MySQLiErrorNr = $stmt->errno;
                $this->MySQLiErrorMsg = $stmt->error;
                $stmt->close();
                return false; // Update failed
            }
        }
        return false; // Statement preparation failed
    }
    
    

    /**
     * Adds a new flight record to the database table - flights.
     * 
     * @param array $postArray Copy of $_POST array containing data to be inserted
     * @return boolean
     */
    public function addFlight($postArray){
        // Extract the values from the form contained in the $postArray argument
        extract($postArray);
    
        // Prepare the form values
        $flightNumber = addslashes($flightNumber);
        $destination = addslashes($destination);
        $departureLocation = addslashes($departureLocation);
        $timeOfDeparture = $timeOfDeparture;
        $timeOfArrival = $timeOfArrival;
        $airline = addslashes($airline);
        $status = addslashes($status); 
    

        $this->SQL = "INSERT INTO flights
                      (FlightNumber, Destination, DepartureLocation, TimeOfDeparture, TimeOfArrival, Airline, Status)
                      VALUES
                      ('$flightNumber', '$destination', '$departureLocation', '$timeOfDeparture', '$timeOfArrival', '$airline', '$status')";

        try {
            $rs = $this->db->query($this->SQL);
        } catch (mysqli_sql_exception $e) {
            $this->MySQLiErrorNr = $e->getCode();
            $this->MySQLiErrorMsg = $e->getMessage();
            return false;
        }
        if ($rs) { return TRUE; } else { return FALSE; }
    }
    
    /**
     * Returns a MySQLi resultset record for the selected flight number if it exists. False if it does not exist.
     * 
     * @param string $flightNumber The flight number to be searched for
     * @return mixed Returns false on failure. For successful SELECT, returns a mysqli_result object.
     */
    public function getRecordByFlightID($flightID) {
        // Construct the SQL query        
        $this->SQL = "SELECT * FROM flights WHERE flight_id = '".$flightID."'";

        // Execute the query
        try {
            $rs = $this->db->query($this->SQL);
            if ($rs->num_rows) {
                return $rs; // Return the recordset
            } else {
                return false;  // No records found
            }  
        } catch (mysqli_sql_exception $e) {
            $this->MySQLiErrorNr = $e->getCode();
            $this->MySQLiErrorMsg = $e->getMessage();
            return false;  // The query failed for some reason
        }         
    }

    /**
     * Retrieves all flight records from the database.
     * 
     * @return mixed Returns false on failure. For successful SELECT, returns a mysqli_result object with all flight records.
     */
    public function getAllFlights() {
        // Construct the SQL query
        $this->SQL = "SELECT * FROM flights";
        
        // Execute the query
        try {
            $rs = $this->db->query($this->SQL);
            if ($rs->num_rows) {
                return $rs; // Return the recordset
            } else {
                return false;  // No records found
            }  
        } catch (mysqli_sql_exception $e) {
            $this->MySQLiErrorNr = $e->getCode();
            $this->MySQLiErrorMsg = $e->getMessage();
            return false;  // The query failed for some reason
        }
    }

    

    public function getAllAirlines() {
        // Construct the SQL query for the airlines table
        $this->SQL = "SELECT * FROM airlines";
        
        // Execute the query
        try {
            $rs = $this->db->query($this->SQL);
            if ($rs->num_rows) {
                return $rs; // Return the recordset containing all airlines
            } else {
                return false;  // No records found in the airlines table
            }
        } catch (mysqli_sql_exception $e) {
            $this->MySQLiErrorNr = $e->getCode();
            $this->MySQLiErrorMsg = $e->getMessage();
            return false;  // The query failed for some reason
        }
    }

    public function getAllBookings() {
        // Construct the SQL query for the airlines table
        $this->SQL = "SELECT * FROM bookings";
        
        // Execute the query
        try {
            $rs = $this->db->query($this->SQL);
            if ($rs->num_rows) {
                return $rs; // Return the recordset containing all airlines
            } else {
                return false;  // No records found in the airlines table
            }
        } catch (mysqli_sql_exception $e) {
            $this->MySQLiErrorNr = $e->getCode();
            $this->MySQLiErrorMsg = $e->getMessage();
            return false;  // The query failed for some reason
        }
    }

    public function handleFlightByID($flightID, $action, $newDetails = []) {
        // First, check if the flight exists
        $flightRecord = $this->getRecordByFlightID($flightID);
        if (!$flightRecord) {
            echo "Flight with ID $flightID does not exist.";
            return false;
        }

        // Handle actions
        switch ($action) {
            case 'edit':
                // Call the updateFlight method to update the flight details
                if ($this->updateFlight($newDetails)) {
                    echo "Flight with ID $flightID has been updated successfully.";
                    return true;
                } else {
                    echo "Failed to update flight with ID $flightID.";
                    return false;
                }
                break;

            case 'delete':
                // Prepare SQL to delete the flight
                $sql = "DELETE FROM flights WHERE flight_id = ?";
                $stmt = $this->db->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param("s", $flightID);
                    if ($stmt->execute()) {
                        echo "Flight with ID $flightID has been deleted successfully.";
                        return true;
                    } else {
                        echo "Failed to delete flight with ID $flightID.";
                        return false;
                    }
                }
                break;

            default:
                echo "Invalid action specified.";
                return false;
        }
    }
    
    
}
