<?php
/**
 * This file contains current release number and notes for this MVC framework
 * 
 * @author gerry.guinane
 * 
 * 
 * 
 */

/*
 * echo the current version
 */
echo '<h2>MVC Framework Version</h2>This version of this MVC Framework release is:'.FRAMEWORK_VERSION;
