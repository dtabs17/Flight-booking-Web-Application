<?php

/**
 * This file contains the Form Class
 * 
 */

/**
 * 
 * Form class - is a helper class that generates HTML forms  
 * 
 *  
 * @author Gerry Guinane
 * 
 */

class Form
{


    /**
     * Generates a HTML user select form 
     * 
     * @param string $pageID The pageID of the page which will be used to process the login form. 
     * @return string String containing the generated form.
     */
    public static function form_select_user($pageID)
    {
        $form = '<form method="post" action="index.php?pageID=' . $pageID . '">';
        $form .= '<div class="form-group">';
        $form .= '<label for="userID">User ID (email)</label><input required type="text" class="form-control" id="userID" name="userID" >';
        $form .= '</div> ';
        $form .= '<button type="submit" class="btn btn-default" value="TRUE" name="btnUserSelect">Select</button>';
        $form .= '</form>';
        return $form;
    }

    public static function form_add_flight($FlightCategoriesTable, $pageID)
    {

        $form = '<form method="post" action="index.php?pageID=' . $pageID . '">';
        $form .= '<div class="form-group">';

        $form .= '<label for="flightNumber">Flight ID</label><input required type="text" class="form-control" id="flightID" name="flightID" pattern="[a-zA-Z0-9\-]{1,11}" title="Flight Number with dashes eg ABC1234-X">';
        $form .= '<label for="destination">Destination</label><input required type="text" class="form-control" id="destination" name="destination">';
        $form .= '<label for="departureLocation">Departure Location</label><input required type="text" class="form-control" id="departureLocation" name="departureLocation">';
        $form .= '<label for="timeOfDeparture">Time of Departure</label><input required type="datetime-local" class="form-control" id="timeOfDeparture" name="timeOfDeparture">';
        $form .= '<label for="timeOfArrival">Time of Arrival</label><input required type="datetime-local" class="form-control" id="timeOfArrival" name="timeOfArrival">';
        $form .= '<label for="airlineid">Airline ID</label><input required type="text" class="form-control" id="airlineid" name="airlineid">';

        $form .= '<label for="status">Flight Status</label>';
        $form .= '<select id="status" name="status" class="form-control">';
        $form .= '<option value="On Time" name="On Time">On Time</option>';
        $form .= '<option value="Delayed" name= "Delayed">Delayed</option>';
        $form .= '<option value="Cancelled name= "Cancelled">Cancelled</option>';
        $form .= '</select>';

        $form .= '</div>';
        $form .= '<button type="submit" class="btn btn-primary" name="btnAddFlight" value="TRUE">Add Flight</button>';
        $form .= '<button type="reset" class="btn btn-secondary">Clear Form</button>';
        $form .= '</form>';

        return $form;
    }

    public static function form_edit_flight($pageID, $flightDetails = null)
    {
        $form = '<form method="post" action="index.php?pageID=' . $pageID . '">';
        $form .= '<div class="form-group">';

        $flightIDValue = isset($flightDetails['flightID']) ? $flightDetails['flightID'] : '';
        $destinationValue = isset($flightDetails['destination']) ? $flightDetails['destination'] : '';
        $departureLocationValue = isset($flightDetails['departureLocation']) ? $flightDetails['departureLocation'] : '';
        $timeOfDepartureValue = isset($flightDetails['timeOfDeparture']) ? $flightDetails['timeOfDeparture'] : '';
        $timeOfArrivalValue = isset($flightDetails['timeOfArrival']) ? $flightDetails['timeOfArrival'] : '';
        $airlineIDValue = isset($flightDetails['airlineid']) ? $flightDetails['airlineid'] : '';
        $statusValue = isset($flightDetails['status']) ? $flightDetails['status'] : '';

        $form .= '<label for="flightNumber">Flight ID</label><input required type="text" class="form-control" id="flightID" name="flightID" value="' . $flightIDValue . '">';
        $form .= '<label for="destination">Destination</label><input required type="text" class="form-control" id="destination" name="destination" value="' . $destinationValue . '">';
        $form .= '<label for="departureLocation">Departure Location</label><input required type="text" class="form-control" id="departureLocation" name="departureLocation" value="' . $departureLocationValue . '">';
        $form .= '<label for="timeOfDeparture">Time of Departure</label><input required type="datetime-local" class="form-control" id="timeOfDeparture" name="timeOfDeparture" value="' . $timeOfDepartureValue . '">';
        $form .= '<label for="timeOfArrival">Time of Arrival</label><input required type="datetime-local" class="form-control" id="timeOfArrival" name="timeOfArrival" value="' . $timeOfArrivalValue . '">';
        $form .= '<label for="airlineid">Airline ID</label><input required type="text" class="form-control" id="airlineid" name="airlineid" value="' . $airlineIDValue . '">';

        $form .= '<label for="status">Flight Status</label>';
        $form .= '<select id="status" name="status" class="form-control">';
        $statusOptions = ['On Time', 'Delayed', 'Cancelled'];
        foreach ($statusOptions as $option) {
            $selected = ($option === $statusValue) ? ' selected' : '';
            $form .= '<option value="' . $option . '"' . $selected . '>' . $option . '</option>';
        }
        $form .= '</select>';

        $form .= '</div>';
        $form .= '<button type="submit" class="btn btn-success" name="btnUpdateFlight" value="TRUE">Update Flight</button>';
        $form .= '<button type="submit" class="btn btn-danger" name="btnDeleteFlight" value="TRUE" onclick="return confirm(\'Are you sure you want to delete this flight?\');">Delete Flight</button>';
        $form .= '<button type="reset" class="btn btn-secondary">Clear Form</button>';
        $form .= '</form>';

        return $form;
    }


    public static function form_initial_flight_id($pageID)
    {
        $form = '<form method="post" action="index.php?pageID=' . $pageID . '">';
        $form .= '<div class="form-group">';

        $form .= '<label for="flightId">Enter Flight ID:</label>';
        $form .= '<input type="number" id="flightId" name="flightId" class="form-control" required>';
        $form .= '<br>';

        $form .= '<button type="submit" name="btnSearch">Search</button>';

        $form .= '</div>';
        $form .= '</form>';

        return $form;
    }


    public static function form_change_user_status($pageID)
    {
        $form = '<form method="post" action="index.php?pageID=' . $pageID . '">';
        $form .= '<div class="form-group">';
    
        $form .= '<label for="userId">Enter User ID:</label>';
        $form .= '<input type="text" id="userId" name="userId" class="form-control" required>';
        $form .= '<br>';

        $form .= '<input type="submit" class="btn btn-warning" name="action" value="Block User">';
        $form .= '<input type="submit" class="btn btn-success" name="action" value="Activate User">';
    
        $form .= '</div>';
        $form .= '</form>';
    
        return $form;
    }
    
    public static function form_book_flight($pageID)
    {
        $form = '<form method="post" action="index.php?pageID=' . $pageID . '">';
        $form .= '<div class="form-group">';

        $form .= '<label for="flightId">Enter Flight ID:</label>';
        $form .= '<input type="text" id="flightId" name="flightId" class="form-control" required>';
        $form .= '<br>';

        $form .= '<label for="userID">Enter User ID (email):</label>';
        $form .= '<input type="email" id="userID" name="userID" class="form-control" required>';
        $form .= '<br>';
    

        $form .= '<input type="submit" class="btn btn-primary" name="submit" value="Book Flight">';
    
        $form .= '</div>';
        $form .= '</form>';
    
        return $form;
    }
    
    public static function form_view_bookings($pageID)
    {
        $form = '<form method="post" action="index.php?pageID=' . $pageID . '">';
        $form .= '<div class="form-group">';
    

        $form .= '<label for="userID">Enter User ID (email):</label>';
        $form .= '<input type="email" id="userID" name="userID"  class="form-control" required>';
        $form .= '<br>';
    
        $form .= '<input type="submit" class="btn btn-primary" name="submit1" value="View Bookings">';
    
        $form .= '</div>';
        $form .= '</form>';
    
        return $form;
    }
    
    public static function form_delete_booking($pageID)
{
    $form = '<form method="post" action="index.php?pageID=' . $pageID . '">';
    $form .= '<div class="form-group">';

    $form .= '<label for="bookingID">Enter Booking ID:</label>';
    $form .= '<input type="text" id="bookingID" name="bookingID" class="form-control" required>';
    $form .= '<br>';

    $form .= '<input type="submit" class="btn btn-danger" name="deleteBooking" value="Delete Booking">';

    $form .= '</div>';
    $form .= '</form>';

    return $form;
}

    public static function form_add_airline($pageID)
    {
        $form = '<form method="post" action="index.php?pageID=' . $pageID . '">';
        $form .= '<div class="form-group">';

        $form .= '<label for="airlineId">Airline ID</label><input required type="text" class="form-control" id="airlineId" name="airlineId" pattern="[0-9]+" title="Airline ID">';
        $form .= '<label for="airlineName">Airline Name</label><input required type="text" class="form-control" id="airlineName" name="airlineName" pattern="[a-zA-Z\s\-]{2,50}" title="Airline Name">';

        $form .= '</div>';
        $form .= '<button type="submit" class="btn btn-primary" name="btnAddAirline" value="TRUE">Add Airline</button>';
        $form .= '<button type="reset" class="btn btn-secondary">Clear Form</button>';
        $form .= '</form>';

        return $form;
    }


    /**
     * Generates a HTML login form 
     * 
     * @param string $pageID The pageID of the page which will be used to process the login form. 
     * @return string String containing the generated form.
     */
    public static function form_login($pageID)
    {
        $form = '<form method="post" action="index.php?pageID=' . $pageID . '">';
        $form .= '<div class="form-group">';
        $form .= '<label for="userID">ID (email)</label><input required type="text" class="form-control" id="userID" name="userID" >';
        $form .= '<label for="password">Password</label><input required type="password" class="form-control" id="password" name="password" >';
        $form .= '</div> ';
        $form .= '<button type="submit" class="btn btn-default" value="TRUE" name="btnLogin">Login</button>';
        $form .= '</form>';
        return $form;
    }

    /**
     * Generates a HTML password change form
     * 
     * @param string $pageID The pageID of the page which will be used to process the login form.
     * @return string String containing the generated form.
     */
    public static function form_password_change($pageID)
    {
        $form = '<form method="post" action="index.php?pageID=' . $pageID . '">';
        $form .= '<div class="form-group">';
        $form .= '<label for="pass1">Enter New Password</label><input required type="password" class="form-control" id="pass1" name="pass1" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">';
        $form .= '<label for="pass2">Re-enter New Password</label><input required type="password" class="form-control" id="pass2" name="pass2" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must match the above password exactly">';
        $form .= '<label for="password">Enter OLD Password</label><input required type="password" class="form-control" id="password" name="password" >';
        $form .= '</div> ';
        $form .= '<button type="submit" class="btn btn-default" value="TRUE" name="btnChangePW">Change Password</button>';
        $form .= '<button type="submit" class="btn btn-default" name="btnCancelUpdatePW" value="updatePWCancel">Cancel</button>';
        $form .= '</form>';
        return $form;
    }

    /**
     * 
     * Generates a HTML form for editing account details. 
     * 
     * The form generated will display but does not permit editing of the users ID.  
     * 
     * @param CountyTable $countyTable A county table entity object.
     * @param mysqli_result $userRecord Resultset containing the current user details from the database  user table 
     * @param string $pageID The pageID of the page which will be used to process the login form.
     * @return string String containing the generated form.
     */
    public static function form_edit_account($countyTable, $userRecord, $pageID)
    {
        $countyList = array();
        $i = 1;
        if ($rs = $countyTable->getAllRecords()) {
            while ($row = $rs->fetch_assoc()) {
                $countyList[$row['idcounty']] = $row['countyName'];
                $i++;
            }
        }

        $userRecordArray = $userRecord->fetch_assoc();
        extract($userRecordArray);

        $form = '<form method="post" action="index.php?pageID=' . $pageID . '">';
        $form .= '<div class="form-group">';

        $form .= '<label for="firstName">First Name</label><input required type="text" class="form-control"  value="' . $FirstName . '" id="firstName" name="firstName" pattern="[a-zA-Z0-9óáéí\']{1,45}" title="First Name (up to 45 Characters)">';
        $form .= '<label for="lastName">Last Name</label><input required type="text" class="form-control"   value="' . $LastName . '" id="lastName" name="lastName" pattern="[a-zA-Z0-9óáéí\']{1,45}" title="Last Name (up to 45 Characters)" >';
        $form .= '<label for="idCounty">county</label>';
        $form .= '<select class="form-control" id="idCounty" name="idCounty">';
        $form .= '<option value="' . $idcounty . '">' . $countyList[$idcounty] . '</option>';
        foreach ($countyList as $key => $value) {
            $form .= '<option value="' . $key . '">' . $value . '</option>';
        }
        $form .= '</select>';

        $form .= '<input type="hidden" id="userTypeNr" name="userTypeNr" value="' . $userTypeNr . '">';
        $form .= '<input type="hidden" id="userEnabled" name="userEnabled" value="1">';

        $form .= '<label for="email">email (not editable)</label><input required readonly type="text" class="form-control" value="' . $email . '" id="email" name="email" pattern="[a-zA-Z0-9@.]{1,45}" title="enter a valid email" >';
        $form .= '<label for="mobile">mobile</label><input type="text" class="form-control" value="' . $mobile . '" id="mobile" name="mobile" pattern="[0-9()+-\']{7,20}" title="enter a valid phone number" >';

        $form .= '</div> ';
        $form .= '<button type="submit" class="btn btn-default" name="btnUpdateAccount" value="update">Update</button>';
        $form .= '<button type="submit" class="btn btn-default" name="btnCancelUpdateAccount" value="update">Cancel Update</button>';
        $form .= '</form>';

        return $form;
    }


    /**
     * 
     * Generates a HTML form for editing account details. 
     * 
     * The form generated will display but does not permit editing of the users ID.  
     * 
     * @param CountyTable $countyTable A county table entity object.
     * @param UserTypeTable $userTypeTable A county table entity object.
     * @param mysqli_result $userRecord Resultset containing the current user details from the database  user table 
     * @param string $pageID The pageID of the page which will be used to process the login form.
     * @return string String containing the generated form.
     */
    public static function form_administrator_edit_account($countyTable, $userTypeTable, $userRecord, $pageID)
    {


        $countyList = array();
        $i = 1;
        if ($rs = $countyTable->getAllRecords()) {
            while ($row = $rs->fetch_assoc()) {
                $countyList[$row['idcounty']] = $row['countyName'];
                $i++;
            }
        }

        $userTypeList = array();
        if ($rs = $userTypeTable->getAllRecords()) {
            while ($row = $rs->fetch_assoc()) {
                $userTypeList[$row['userTypeNr']] = $row['userTypeDescr'];
            }
        }


        $userRecordArray = $userRecord->fetch_assoc();
        extract($userRecordArray);

        $form = '<form method="post" action="index.php?pageID=' . $pageID . '">';
        $form .= '<div class="form-group">';
        $form .= '<label for="userID">User ID (not editable)</label><input required readonly type="text" class="form-control"   value="' . $userID . '" id="userID" name="userID" >';
        $form .= '<label for="firstName">First Name</label><input required type="text" class="form-control"  value="' . $FirstName . '" id="firstName" name="firstName" pattern="[a-zA-Z0-9óáéí\']{1,45}" title="First Name (up to 45 Characters)">';
        $form .= '<label for="lastName">Last Name</label><input required type="text" class="form-control"   value="' . $LastName . '" id="lastName" name="lastName" pattern="[a-zA-Z0-9óáéí\']{1,45}" title="Last Name (up to 45 Characters)" >';

        $form .= '<label for="idCounty">County</label>';
        $form .= '<select class="form-control" id="idCounty" name="idCounty">';
        $form .= '<option value="' . $idcounty . '">' . $countyList[$idcounty] . '</option>';
        foreach ($countyList as $key => $value) {
            $form .= '<option value="' . $key . '">' . $value . '</option>';
        }
        $form .= '</select>';


        $form .= '<label for="userTypeNr">Select Usertype</label>';
        $form .= '<select class="form-control" id="userTypeNr" name="userTypeNr">';
        $form .= '<option value="' . $userTypeNr . '" selected>' . $userTypeDescr . '</option>';
        foreach ($userTypeList as $key => $value) {
            $form .= '<option value="' . $key . '">' . $value . '</option>';
        }
        $form .= '</select>';


        $form .= '<label for="userEnabled">Enable/Disable User Access</label>';
        $form .= '<select class="form-control" id="userEnabled" name="userEnabled">';
        if ($userEnabled) {
            $form .= '<option value="1">LOGIN ENABLED</option>';
            $form .= '<option value="0">DISABLE LOGIN</option>';
        } else {
            $form .= '<option value="0">LOGIN NOT ENABLED</option>';
            $form .= '<option value="1">ENABLE LOGIN</option>';
        }
        $form .= '</select>';


        $form .= '<label for="email">email (not editable)</label><input required readonly type="text" class="form-control" value="' . $email . '" id="email" name="email" pattern="[a-zA-Z0-9@.]{1,45}" title="enter a valid email" >';
        $form .= '<label for="mobile">mobile</label><input type="text" class="form-control" value="' . $mobile . '" id="mobile" name="mobile" pattern="[0-9()+-\']{7,20}" title="enter a valid phone number" >';

        $form .= '</div> ';
        $form .= '<button type="submit" class="btn btn-default" name="btnUpdateAccount" value="update">Update</button>';
        $form .= '<button type="submit" class="btn btn-default" name="btnCancelUpdateAccount" value="update">Cancel Update</button>';
        $form .= '</form>';

        return $form;
    }



    /**
     * Generates a HTML form for registering a new  account.  It is intended for administrator use
     * 
     * The form generated will display a drop down list/chooser of counties and user types.  
     * 
     * @param CountyTable $countyTable A county table entity object.
     * @param UserTypeTable $userTypeTable A county table entity object.
     * @param string $pageID The pageID of the page which will be used to process the login form.
     * @return string String containing the generated form.
     */
    public static function form_register($countyTable,$userTypeTable, $pageID){
        $countyList=array();
        if($rs=$countyTable->getAllRecords()){
            while ($row = $rs->fetch_assoc()){
                $countyList[$row['idcounty']]=$row['countyName'];
            }
        } 
        
        $userTypeList=array();
        if($rs=$userTypeTable->getAllRecords()){
            while ($row = $rs->fetch_assoc()){
                $userTypeList[$row['userTypeNr']]=$row['userTypeDescr'];
            }
        } 
        
        $form='<form method="post" action="index.php?pageID='.$pageID.'">';
        $form.='<div class="form-group">';
        $form.='<label for="firstName">First Name</label><input required type="text" class="form-control" id="firstName" name="firstName" pattern="[a-zA-Z0-9óáéí\']{1,45}" title="First Name (up to 45 Characters)">';
        $form.='<label for="lastName">Last Name</label><input required type="text" class="form-control" id="lastName" name="lastName" pattern="[a-zA-Z0-9óáéí\']{1,45}" title="Last Name (up to 45 Characters)" >';

        $form.='<label for="idCounty">County (select your county)</label>';
        $form.='<select class="form-control" id="idCounty" name="idCounty">';
              $form.= '<option value="99" selected>Select a County</option>';
          foreach($countyList as $key=>$value){
              $form.= '<option value="'.$key.'">'.$value.'</option>';  
          }
        $form.='</select>';

        $form.='<label for="userTypeNr">Select Usertype</label>';
        $form.='<select class="form-control" id="userTypeNr" name="userTypeNr">';
              $form.= '<option value="99" selected>Select a User Type</option>';
          foreach($userTypeList as $key=>$value){
              $form.= '<option value="'.$key.'">'.$value.'</option>';  
          }
        $form.='</select>';

        $form.='<label for="userEnabled">Enable/Disable User Access</label>';
        $form.='<select class="form-control" id="userEnabled" name="userEnabled">';
                  $form.= '<option value="1" selected>LOGIN ENABLED(DEFAULT)</option>';  
                  $form.= '<option value="0">LOGIN NOT ENABLED </option>';  
                  $form.= '<option value="1">ENABLE LOGIN</option>'; 
        $form.='</select>';

        $form.='<label for="email">email (this will be your user ID) </label><input type="text" class="form-control" id="email" name="email" pattern="[a-zA-Z0-9@.]{1,45}" title="enter a valid email" >';
        $form.='<label for="mobile">mobile</label><input type="text" class="form-control" id="mobile" name="mobile" pattern="[0-9()+-\']{7,20}" title="enter a valid phone number" >';
        $form.='<label for="pass1">Password</label><input required type="password" class="form-control" id="pass1" name="pass1" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">';
        $form.='<label for="pass2">Re-enterPassword</label><input required type="password" class="form-control" id="pass2" name="pass2" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must match the above password exactly">';
        $form.='</div> ';
        $form.='<button type="submit" class="btn btn-default" name="btnRegister" value="registerUser">Register</button>';
        $form.='</form>';
        
        return $form;
    }
    


    /**
     * Generates a HTML form for registering a new  account.  It is intended for CUSTOMER use
     * 
     * The form generated will display a drop down list/chooser of counties and user types.  
     * 
     * @param CountyTable $countyTable A county table entity object.
     * @param string $pageID The pageID of the page which will be used to process the login form.
     * @return string String containing the generated form.
     */
    public static function form_register_customer($countyTable,$pageID){
        $countyList=array();
        if($rs=$countyTable->getAllRecords()){
            while ($row = $rs->fetch_assoc()){
                $countyList[$row['idcounty']]=$row['countyName'];
            }
        } 
        

        
        $form='<form method="post" action="index.php?pageID='.$pageID.'">';
        $form.='<div class="form-group">';
        $form.='<label for="firstName">First Name</label><input required type="text" class="form-control" id="firstName" name="firstName" pattern="[a-zA-Z0-9óáéí\']{1,45}" title="First Name (up to 45 Characters)">';
        $form.='<label for="lastName">Last Name</label><input required type="text" class="form-control" id="lastName" name="lastName" pattern="[a-zA-Z0-9óáéí\']{1,45}" title="Last Name (up to 45 Characters)" >';

        $form.='<label for="idCounty">County (select your county)</label>';
        $form.='<select class="form-control" id="idCounty" name="idCounty">';
              $form.= '<option value="99" selected>Select a County</option>';
          foreach($countyList as $key=>$value){
              $form.= '<option value="'.$key.'">'.$value.'</option>';  
          }
        $form.='</select>';

        $form.= '<input type="hidden" id="userTypeNr" name="userTypeNr" value="3">';
        $form.= '<input type="hidden" id="userEnabled" name="userEnabled" value="1">';


        $form.='<label for="email">email (this will be your user ID) </label><input type="text" class="form-control" id="email" name="email" pattern="[a-zA-Z0-9@.]{1,45}" title="enter a valid email" >';
        $form.='<label for="mobile">mobile</label><input type="text" class="form-control" id="mobile" name="mobile" pattern="[0-9()+-\']{7,20}" title="enter a valid phone number" >';
        $form.='<label for="pass1">Password</label><input required type="password" class="form-control" id="pass1" name="pass1" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">';
        $form.='<label for="pass2">Re-enterPassword</label><input required type="password" class="form-control" id="pass2" name="pass2" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must match the above password exactly">';
        $form.='</div> ';
        $form.='<button type="submit" class="btn btn-default" name="btnRegister" value="registerUser">Register</button>';
        $form.='</form>';
        
        return $form;
    }
        
    




    /**
     * Generates a HTML form for entering a chat message and optionally specifying a recipient. 
     * 
     * 
     * @param string $pageID The pageID of the page which will be used to process the login form.
     * @return string String containing the generated form.
     */
    public static function form_add_msg($pageID)
    {
        $form = '<div class="container-fluid">';
        $form .= '<form method="post" action="index.php?pageID=' . $pageID . '">';

        $form .= '<div class="form-group">';

        $form .= '<label for="message">Enter a Message</label><textarea class="form-control" id="message" name="message" rows="3" style="resize:vertical"></textarea> ';

        $form .= '<label for="msgTo">Addressed To (enter ID or leave blank for ALL)</label><input type="text" class="form-control" id="msgTo" name="msgTo" >';
        $form .= '</div> ';
        $form .= '<button type="submit" class="btn btn-default" value="TRUE" name="btnAddMsg">Submit Message</button>';
        $form .= '</form>';
        $form .= '</div>';
        return $form;
    }


    /**
     * Generates a HTML CONFIRM form (Button)
     * 
     * @param string $pageID The pageID of the page which will be used to process the login form. 
     * @param string $choice The value of the chosen variable to be confirmed. 
     * @param string $btnText The text to appear on the form button. 
     * @return string String containing the generated form.
     */
    public static function form_confirm($pageID, $btnText, $choice)
    {
        $form = '<form method="post" action="index.php?pageID=' . $pageID . '">';
        $form .= '<button type="submit" class="btn btn-default" value=' . $choice . ' name="btnConfirm">' . $btnText . '</button>';
        $form .= '<button type="submit" class="btn btn-default" value=' . FALSE . ' name="btnConfirm">CANCEL</button>';
        $form .= '</form>';
        return $form;
    }
}
